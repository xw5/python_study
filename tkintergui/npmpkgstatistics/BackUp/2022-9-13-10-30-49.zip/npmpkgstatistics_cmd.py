#coding=utf-8
import sys
import os
from   os.path import abspath, dirname
sys.path.append(abspath(dirname(__file__)))
import tkinter
import tkinter.filedialog
from   tkinter import *
import Fun
ElementBGArray={}  
ElementBGArray_Resize={} 
ElementBGArray_IM={} 

from runfun import statisticsAction
def progressAction(uiName, value):
    Fun.SetTKAttrib(uiName, 'Progress_13', 'value', value)
def successBack(uiName, libs):
    Fun.SetText(uiName, 'Text_10', ('\n').join(libs))
def Form_1_onLoad(uiName):
    Fun.SetText(uiName, 'Text_4', 'version\nlicense\nhomepage')
def Button_3_onCommand(uiName,widgetName):
    proDir = tkinter.filedialog.askdirectory()
    Fun.SetText(uiName, 'Entry_2', proDir)
def Button_12_onCommand(uiName,widgetName):
    outDir = tkinter.filedialog.askdirectory()
    Fun.SetText(uiName, 'Entry_11', outDir)

def Button_9_onCommand(uiName,widgetName):
    print('开始运行0')
    proDir = Fun.GetText(uiName, 'Entry_2')
    outDir = Fun.GetText(uiName, 'Entry_11')
    keysStr = Fun.GetText(uiName, 'Text_4')
    keys = keysStr.split('\n')
    print('开始运行1', proDir, outDir)
    statisticsAction(proDir, outDir, keys, progressAction, successBack, uiName)
