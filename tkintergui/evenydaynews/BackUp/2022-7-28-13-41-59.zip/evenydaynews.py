#coding=utf-8
#import libs 
import sys
import evenydaynews_cmd
import evenydaynews_sty
import Fun
import os
import tkinter
from   tkinter import *
import tkinter.ttk
import tkinter.font
#Add your Varial Here: (Keep This Line of comments)
#Define UI Class
class  evenydaynews:
    def __init__(self,root,isTKroot = True):
        uiName = self.__class__.__name__
        Fun.Register(uiName,'UIClass',self)
        self.root = root
        Fun.Register(uiName,'root',root)
        style = evenydaynews_sty.SetupStyle()
        if isTKroot == True:
            root.title("Form1")
            Fun.CenterDlg(uiName,root,640,606)
            root['background'] = '#efefef'
        Form_1= tkinter.Canvas(root,width = 10,height = 4)
        Form_1.place(x = 0,y = 0,width = 640,height = 606)
        Form_1.configure(bg = "#efefef")
        Form_1.configure(highlightthickness = 0)
        Fun.Register(uiName,'Form_1',Form_1)
        #Create the elements of root 
        ComboBox_5_Variable = Fun.AddTKVariable(uiName,'ComboBox_5')
        ComboBox_5 = tkinter.ttk.Combobox(Form_1,textvariable=ComboBox_5_Variable, state="readonly")
        Fun.Register(uiName,'ComboBox_5',ComboBox_5)
        Fun.SetControlPlace(uiName,'ComboBox_5',135,37,209,30)
        ComboBox_5.configure(state = "normal")
        ComboBox_5["values"]=['网易365资讯简报','人民日报今日要闻']
        ComboBox_5.current(0)
        ComboBox_5.bind("<<ComboboxSelected>>",Fun.EventFunction_Adaptor(evenydaynews_cmd.ComboBox_5_onSelect,uiName=uiName,widgetName="ComboBox_5"))
        Label_6 = tkinter.Label(Form_1,text="新闻源：")
        Fun.Register(uiName,'Label_6',Label_6)
        Fun.SetControlPlace(uiName,'Label_6',21,37,100,30)
        Label_6.configure(anchor = "w")
        Label_6.configure(relief = "flat")
        Text_7 = tkinter.Text(Form_1)
        Fun.Register(uiName,'Text_7',Text_7)
        Fun.SetControlPlace(uiName,'Text_7',17,109,434,481)
        Text_7.configure(relief = "sunken")
        Text_7_Scrollbar = tkinter.Scrollbar(Text_7,orient=tkinter.VERTICAL)
        Text_7_Scrollbar.place(x = 414,y = 0,width = 20,height = 481)
        Text_7_Scrollbar.config(command = Text_7.yview)
        Text_7.config(yscrollcommand = Text_7_Scrollbar.set)
        Fun.Register(uiName,'Text_7_Scrollbar',Text_7_Scrollbar)
        Button_8 = tkinter.Button(Form_1,text="开始")
        Fun.Register(uiName,'Button_8',Button_8)
        Fun.SetControlPlace(uiName,'Button_8',513,37,100,30)
        Label_9 = tkinter.Label(Form_1,text="新闻内容：")
        Fun.Register(uiName,'Label_9',Label_9)
        Fun.SetControlPlace(uiName,'Label_9',21,74,100,30)
        Label_9.configure(anchor = "w")
        Label_9.configure(relief = "flat")
        #Inital all element's Data 
        Fun.InitElementData(uiName)
        #Add Some Logic Code Here: (Keep This Line of comments)


#Create the root of Kinter 
if  __name__ == '__main__':
    root = tkinter.Tk()
    MyDlg = evenydaynews(root)
    root.mainloop()
